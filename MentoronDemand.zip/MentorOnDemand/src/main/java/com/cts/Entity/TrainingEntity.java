package com.cts.Entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="trainingRecords")
public class TrainingEntity implements Serializable{

	
	private String trainingId;
	private String userId;
	private String mentorId;
	private int fees;
	private int rating;
	private String status;
	private double commission;
	private String startDate;
	private String lastDate;
	public String getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMentorId() {
		return mentorId;
	}
	public void setMentorId(String mentorId) {
		this.mentorId = mentorId;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getCommission() {
		return commission;
	}
	public void setCommission(double commission) {
		this.commission = commission;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getLastDate() {
		return lastDate;
	}
	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}
	@Override
	public String toString() {
		return "Training [trainingId=" + trainingId + ", userId=" + userId + ", mentorId=" + mentorId + ", fees=" + fees
				+ ", rating=" + rating + ", status=" + status + ", commission=" + commission + ", startDate="
				+ startDate + ", lastDate=" + lastDate + "]";
	}
	
	
	

}
