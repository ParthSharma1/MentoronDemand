package com.cts.Entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="User")
public class UserEntity implements Serializable{

	private String userId;
	private String Name;
	private String password;
	private String eMail;
	private String contactNo;
	private String DOB;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", Name=" + Name + ", password=" + password + ", eMail=" + eMail
				+ ", contactNo=" + contactNo + ", DOB=" + DOB + "]";
	}
	
	
	
	
	
	
}
