package com.cts.Entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="Mentor")
public class MentorEntity implements Serializable{
	
	private String mentorId;
	private String eMail;
	private String password;
	private String fName;
	private String lName;
	private String contactNo;
	private String yearsofExperience;
	private String specialization;
	private String noofTrainingDone;
	public String getMentorId() {
		return mentorId;
	}
	public void setMentorId(String mentorId) {
		this.mentorId = mentorId;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getYearsofExperience() {
		return yearsofExperience;
	}
	public void setYearsofExperience(String yearsofExperience) {
		this.yearsofExperience = yearsofExperience;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getNoofTrainingDone() {
		return noofTrainingDone;
	}
	public void setNoofTrainingDone(String noofTrainingDone) {
		this.noofTrainingDone = noofTrainingDone;
	}
	@Override
	public String toString() {
		return "Mentor [mentorId=" + mentorId + ", eMail=" + eMail + ", password=" + password + ", fName=" + fName
				+ ", lName=" + lName + ", contactNo=" + contactNo + ", yearsofExperience=" + yearsofExperience
				+ ", specialization=" + specialization + ", noofTrainingDone=" + noofTrainingDone + "]";
	}
	
	
	
	
	
}
